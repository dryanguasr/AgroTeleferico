from pathlib import Path
import csv,json,sys,hashlib,itertools
base=Path(__file__).resolve().parent; root=base.parents[1]
sys.path.insert(0,str(root/'scripts'))
from analyze_demand import CONTRASTS,bootstrap_columns,describe
folder=root/'results/demand_analysis_02'; source=folder/'run_metrics.csv'
rows=list(csv.DictReader(source.open()))
metrics=('positive_J_per_useful_kg','loss_work_J','load_energy_J','residual_J','predictor_absolute_error_J','trips','handling_s','restoration_time_s','operator_busy_lower_fraction','operator_busy_upper_fraction')
assert len(rows)==720 and all(r['state']=='completed' and float(r['delivered_useful_kg'])>0 for r in rows)
for row in rows:
 for field in metrics:
  if field.endswith('_fraction'):
   station=field.removeprefix('operator_busy_').removesuffix('_fraction'); row[field]=float(row['operator_busy_'+station+'_s'])/float(row['simulation_s']); assert 0<=row[field]<=1
  else: row[field]=float(row[field])
result=[]
for rate,pattern in itertools.product(('12','24','36'),('balanced','alternating')):
 group=[r for r in rows if r['rate_per_hour']==rate and r['pattern']==pattern]
 paired={seed:{r['policy']:r for r in group if int(r['seed'])==seed} for seed in range(30)}
 for contrast,coefficients in CONTRASTS.items():
  assert all(set(p)==set('ABCD') for p in paired.values())
  columns={m:[sum(coefficient*paired[seed][policy][m] for policy,coefficient in coefficients.items()) for seed in range(30)] for m in metrics}
  draws=bootstrap_columns(columns,['agro-demand-bootstrap-v1',int(rate),pattern,contrast],10000)
  for metric in metrics: result.append({'rate_per_hour':rate,'pattern':pattern,'contrast':contrast,'metric':metric,'planned_pairs':30,'excluded_pairs':0,**describe(columns[metric],draws[metric],.95)})
path=folder/'derived_comparisons.csv'; assert not path.exists()
with path.open('w',newline='') as stream:
 writer=csv.DictWriter(stream,fieldnames=list(result[0])); writer.writeheader(); writer.writerows(result)
(folder/'derived_analysis.json').write_text(json.dumps({'classification':'verified derived computational statistics','input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'bootstrap_replicates':10000,'method':'paired seed resampling; same deterministic keys as main analysis','metrics':metrics,'n_per_group':30,'excluded_pairs':0,'occupancy':'operator busy time divided by whole run time; stations reported separately','energy_per_kg':'ratio per seed before paired subtraction; no ratio of means'},indent=2))
print('Derived comparisons',len(result),flush=True)
