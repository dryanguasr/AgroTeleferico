from pathlib import Path
import argparse, hashlib, json, subprocess, sys, time
base=Path(__file__).resolve().parent
root=base.parents[1]
campaign=root/'results/demand_campaign_02'
parser=argparse.ArgumentParser(); parser.add_argument('--phase',choices=['native','media','compose'],required=True); parser.add_argument('--host-memory',required=True); parser.add_argument('--resume',action='store_true'); args=parser.parse_args()
audit=json.loads((campaign/'audit_full_01.json').read_text()); assert audit['passed'] and audit['passed_audits']==720
selection_file=root/'results/demand_analysis_02/representative.json'
if selection_file.exists():
 selected=json.loads(selection_file.read_text())
else:
 sys.path.insert(0,str(root/'scripts'))
 from analyze_demand import select_representative
 datasets={r['id']:r for r in json.loads((campaign/'dataset.json').read_text())['datasets']}
 rows=[]
 for row in json.loads((campaign/'campaign.json').read_text())['runs']:
  if row['dataset'].startswith('alternating_r24_'):
   summary=json.loads((campaign/row['attempt']/'output/demand_summary.json').read_text())
   rows.append({**datasets[row['dataset']],**row,'summary':summary})
 selected=select_representative(rows,json.loads((campaign/'config.json').read_text())['analysis'])
 (base/'selection_before_analysis.json').write_text(json.dumps(selected,indent=2))
assert selected['selected'] and selected['eligible_seeds']==30
request=campaign/selected['input_path']; assert hashlib.sha256(request.read_bytes()).hexdigest()==selected['input_sha256']
status={'phase':args.phase,'selected':selected,'commands':[],'passed':False}
status_path=base/(args.phase+('_resume_01' if args.resume else '')+'_status.json')
assert not status_path.exists(), 'Use fresh output for each attempt'
def run(label,argv):
 entry={'label':label,'argv':argv,'started_unix_s':time.time()}; status['commands'].append(entry); status_path.write_text(json.dumps(status,indent=2))
 with (base/(label+'.log')).open('w') as log:
  result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
 entry.update(exit_code=result.returncode,wall_s=time.time()-entry['started_unix_s']); status_path.write_text(json.dumps(status,indent=2))
 if result.returncode: raise RuntimeError(label+' failed; inspect preserved log')
common=['--demand',str(request),'--dispatch-config',str(campaign/'dispatch.params'),'--predictor',str(campaign/'predictor.csv'),'--host-memory',args.host_memory]
for policy in 'ABCD':
 if args.phase=='native':
  out=base/('native_'+policy)
  validation=out/'validation.json'
  if args.resume and validation.exists():
   previous=json.loads(validation.read_text())
   if previous['passed']:
    assert all(value['identical'] for value in previous['parity'].values())
    continue
   out=base/('native_'+policy+'_retry_01')
  run(out.name,[sys.executable,'scripts/validate_demand_native.py','--output',str(out),'--policy',policy,'--timeout','900']+common)
  generated=out/'pilot/generated/loop.params'
  assert generated.read_bytes()==(campaign/'loop.params').read_bytes(), 'Native and campaign physics parameters differ'
  source=campaign/selected['runs'][policy]/'output/demand_summary.json'
  native=out/'pilot/generated/gazebo/demand_summary.json'
  assert json.loads(source.read_text())==json.loads(native.read_text()), 'Full native and campaign summaries differ'
  mapping=base/'native_paths.json'; paths=json.loads(mapping.read_text()) if mapping.exists() else {}
  paths[policy]=str(out.relative_to(base)); mapping.write_text(json.dumps(paths,indent=2))
 elif args.phase=='media':
  capture=base/('capture_'+policy)
  run('capture_'+policy+('_retry_01' if args.resume else ''),[sys.executable,'scripts/capture_loop.py','--output',str(capture),'--scenario','buitrago_patio','--variant','revised_supports','--view','overview','--video','--follow-carrier','0','--until','1200','--video-start','600','--video-end','1200','--real-time-factor','4','--timeout','1800','--policy',policy]+common)
  assert (capture/'pilot/generated/loop.params').read_bytes()==(campaign/'loop.params').read_bytes()
  run('verify_capture_'+policy,[sys.executable,'scripts/validate_demand_native.py','--capture',str(capture),'--output',str(base/('capture_validation_'+policy)),'--host-memory',args.host_memory])
 else:
  run('compose_'+policy,[sys.executable,'scripts/compose_demand_hud.py','--capture',str(base/('capture_'+policy)),'--output',str(base/('hud_'+policy))])
status['passed']=True; status_path.write_text(json.dumps(status,indent=2)); print(json.dumps({'phase':args.phase,'passed':True}),flush=True)
