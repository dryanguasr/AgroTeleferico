from pathlib import Path
import csv, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
base=Path(__file__).resolve().parent
analysis=base.parents[1]/'results/demand_analysis_02'
rows=list(csv.DictReader((analysis/'comparisons.csv').open()))
fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
colors=['#1976a3','#598c37','#c77a22']
for ax,metric,scale,title in [(axes[0],'drive_positive_J',1,'Trabajo motriz positivo (J)'),(axes[1],'on_time_fraction',100,'Entregas a tiempo (puntos porcentuales)')]:
 for j,contrast in enumerate(['B-A','C-A','D-A']):
  row=next(r for r in rows if r['rate_per_hour']=='24' and r['pattern']=='alternating' and r['contrast']==contrast and r['metric']==metric)
  mean,lo,hi=[float(row[k])*scale for k in ('mean','ci95_low','ci95_high')]
  ax.errorbar(mean,2-j,xerr=[[mean-lo],[hi-mean]],fmt='o',capsize=5,color=colors[j],linewidth=2)
 ax.set_yticks([2,1,0],['B − A','C − A','D − A']); ax.axvline(0,color='#68717a',linewidth=1); ax.grid(axis='x',alpha=.2); ax.set_xlabel(title)
 ax.spines[['top','right']].set_visible(False)
fig.suptitle('Demanda alternante · 24 pedidos/h · diferencias pareadas, IC bootstrap 95 %',fontsize=12)
fig.savefig(base/'comparacion_nominal.png',dpi=180)
fig.savefig(base/'comparacion_nominal.svg')
print('Figure written')
