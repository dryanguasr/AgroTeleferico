from pathlib import Path
import csv,json,statistics,hashlib,shutil,subprocess,sys,zipfile
base=Path(__file__).resolve().parent; root=base.parents[1]
analysis=root/'results/demand_analysis_02'; campaign=root/'results/demand_campaign_02'
evidence=root/'docs/evidence/demand_pilot_20261026'
assert not evidence.exists()
a=json.loads((analysis/'analysis.json').read_text()); audit=json.loads((campaign/'audit_full_01.json').read_text())
assert a['all_runs_completed_comparable'] and audit['passed'] and audit['passed_audits']==720
selected=json.loads((analysis/'representative.json').read_text())
assert json.loads((analysis/'derived_analysis.json').read_text())['excluded_pairs']==0
visual=json.loads((base/'visual_review.json').read_text()); assert visual['passed'] and set(visual['policies'])==set('ABCD')
assert selected==json.loads((base/'selection_before_analysis.json').read_text())
rows=list(csv.DictReader((analysis/'run_metrics.csv').open())); comparisons=list(csv.DictReader((analysis/'comparisons.csv').open()))
assert len(rows)==720
assert all(json.loads((base/f'hud_{p}/audit.json').read_text())['composer_sha256']==hashlib.sha256((root/'scripts/compose_demand_hud.py').read_bytes()).hexdigest() for p in 'ABCD')
native_paths=json.loads((base/'native_paths.json').read_text()); assert set(native_paths)==set('ABCD')
for p in 'ABCD':
 for artifact in (base/native_paths[p]/'validation.json',base/f'capture_validation_{p}/validation.json',base/f'hud_{p}/audit.json'):
  assert json.loads(artifact.read_text())['passed'],str(artifact)
evidence.mkdir(parents=True)
for p,name in zip('ABCD',('A_inmediato.mp4','B_coordinado.mp4','C_inmediato_buffers.mp4','D_coordinado_buffers.mp4')):
 shutil.copy2(base/f'hud_{p}'/name,evidence/name)
 preview=base/f'hud_{p}_buffer_preview/preview.png' if p in ('C','D') else base/f'hud_{p}/qa_01500.png'
 shutil.copy2(preview,evidence/f'{p}_preview.png')
for extra in ('visual_review.json','versions.json','historical_artifacts_check.json','analysis_execution.json','native_paths.json','media_regression.log','hud_regression.log','cli_admission_profile_fix.json','validation_summary.json','final_core_source_check.json','capture_matrix_check.json'):
 shutil.copy2(base/extra,evidence/extra)
for path in analysis.iterdir():
 if path.is_file(): shutil.copy2(path,evidence/path.name)
for path in (base/'comparacion_nominal.png',base/'comparacion_nominal.svg',campaign/'audit_full_01.json',campaign/'dataset.json',campaign/'execution.json',campaign/'campaign.json',campaign/'config.json',campaign/'input_continuity.json',root/'results/demand_preflight_02/preflight.json',root/'results/demand_preflight_02/ctest.log',root/'results/demand_revision_02/source_and_binaries.zip'):
 shutil.copy2(path,evidence/path.name)
# Compact evidence keeps all events and inventory records without copying dense native CSVs.
with zipfile.ZipFile(evidence/'eventos_campana.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for path in campaign.rglob('*'):
  if path.is_file() and (path.name in ('orders.csv','trips.csv','operations.csv','inventory.csv','demand_status.csv','demand_summary.json','summary.json','run_record.json','requests.csv') or path.parent==campaign and path.suffix in ('.json','.params','.csv')):
   archive.write(path,path.relative_to(campaign))
with zipfile.ZipFile(evidence/'validacion_y_procedencia.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for p in 'ABCD':
  for folder,names in [(base/native_paths[p],('validation.json','gazebo.log','reference.log','resources.jsonl')),(base/f'capture_validation_{p}',('validation.json',)),(base/f'capture_{p}',('capture.json','camera_coverage.json','frame_times_overview.csv','frame_times_follow.csv','gazebo.log','resources.jsonl')),(base/f'hud_{p}',('audit.json','decode.log','encode.log'))]:
   for name in names:
    path=folder/name
    if path.exists(): archive.write(path,path.relative_to(base))
 for folder in ('demand_campaign_guard_02','demand_native_guard_02','demand_native_guard_03','demand_media_guard_02','demand_media_guard_03','demand_compose_guard_02','demand_compose_a_guard_01','demand_compose_a_guard_02','demand_compose_b_guard_01','demand_compose_c_guard_01','demand_compose_d_guard_01','demand_capture_verify_d_guard_02'):
  for name in ('admission.json','guard_summary.json','supervisor.json','task.json','resources.jsonl'):
   path=root/'results'/folder/name
   if path.exists(): archive.write(path,'guards/'+folder+'/'+name)
 for path in (base/'native_C/validation.json',base/'native_C.log',base/'capture_A.log',base/'compose_A_path_failed_01/audit.json',base/'capture_validation_D_admission_failed_01/validation.json',base/'verify_capture_D.log'):
  if path.exists(): archive.write(path,path.relative_to(base))
 for name in ('run_delivery.py','native_status.json','native_resume_01_status.json','media_status.json','media_resume_01_status.json','compose_status.json','campaign_source_check.json','selection_before_analysis.json','plot_comparison.py','extend_analysis.py','compute_carrier_occupancy.py','export_report.py'):
  path=base/name
  if path.exists(): archive.write(path,name)
mean=lambda group,key: statistics.mean(float(r[key]) for r in group)
nominal=[r for r in rows if r['rate_per_hour']=='24' and r['pattern']=='alternating']
lines=['# Resultados del piloto de demanda y buffers','', '**Verificado:** 720/720 ejecuciones completadas y comparables, 0 fallidas, 0 pendientes; auditoría independiente aprobada en las 720. Las 30 semillas permanecen en cada grupo. Los 47 archivos históricos del manifiesto permanecen intactos. Las fuentes y el binario coinciden con la campaña; no se mezclan los intentos preliminares.', '', 'Los supuestos y el contrato de operación se describen en [piloto_demanda.md](piloto_demanda.md). Las medias de cumplimiento siguientes son medias de las fracciones de cada semilla, no una fracción agregada de todos los pedidos.','', '## Caso nominal: 24 pedidos/h, predominio alternado','', '| Política | Motor positivo medio J | J/kg útil medio | Pedidos a tiempo % | Masa a tiempo % | p95 retraso medio s | Tiempo medio s | Módulos transportados kg |','|---|---:|---:|---:|---:|---:|---:|---:|']
for p in 'ABCD':
 g=[r for r in nominal if r['policy']==p]
 lines.append(f'| {p} | {mean(g,"drive_positive_J"):.2f} | {mean(g,"positive_J_per_useful_kg"):.3f} | {100*mean(g,"on_time_fraction"):.2f} | {100*mean(g,"on_time_mass_fraction"):.2f} | {mean(g,"lateness_p95_s"):.2f} | {mean(g,"simulation_s"):.2f} | {mean(g,"buffer_moves_kg"):.2f} |')
lines+=['','| Diferencia pareada nominal | Motor positivo J: media [IC 95 %] | Cumplimiento: puntos porcentuales [IC 95 %] |','|---|---:|---:|']
for contrast in ('B-A','C-A','D-A','D-C','(D-C)-(B-A)'):
 parts=[]
 for metric,scale in [('drive_positive_J',1),('on_time_fraction',100)]:
  r=next(r for r in comparisons if r['rate_per_hour']=='24' and r['pattern']=='alternating' and r['contrast']==contrast and r['metric']==metric)
  assert r['n']=='30' and r['excluded_pairs']=='0'
  parts.append(f'{float(r["mean"])*scale:+.2f} [{float(r["ci95_low"])*scale:+.2f}, {float(r["ci95_high"])*scale:+.2f}]')
 lines.append('| '+contrast+' | '+' | '.join(parts)+' |')
lines+=['','![Comparación nominal](evidence/demand_pilot_20261026/comparacion_nominal.png)','','Las 720 ejecuciones corresponden a 180 realizaciones compartidas entre cuatro políticas; no son 720 muestras independientes. Cada contraste por intensidad y patrón usa 30 semillas pareadas. Los intervalos son percentiles del promedio de diferencias pareadas, con 10 000 remuestreos de semillas. Son intervalos por contraste, sin corrección por comparaciones múltiples. **Inferido:** describen la variabilidad de estas demandas sintéticas; no acreditan ahorro de electricidad real ni superioridad universal de una política.','','## Matriz completa de medias','','| Pedidos/h | Patrón | Política | Motor J | Pedidos a tiempo % | Masa a tiempo % | Viajes | Restitución J |','|---:|---|---|---:|---:|---:|---:|---:|']
for rate in ('12','24','36'):
 for pattern in ('balanced','alternating'):
  for p in 'ABCD':
   g=[r for r in rows if r['rate_per_hour']==rate and r['pattern']==pattern and r['policy']==p]
   lines.append(f'| {rate} | {pattern} | {p} | {mean(g,"drive_positive_J"):.2f} | {100*mean(g,"on_time_fraction"):.2f} | {100*mean(g,"on_time_mass_fraction"):.2f} | {mean(g,"trips"):.2f} | {mean(g,"restoration_positive_J"):.2f} |')
occupancy_rows=list(csv.DictReader((analysis/'carrier_occupancy.csv').open()))
lines+=['', '## Ocupación nominal', '', 'La ocupación de carros pondera la masa por el arco nominal de cada viaje y divide por dos carros de 10 kg; incluye viajes vacíos y restitución. La de operarios divide su tiempo ocupado por el tiempo completo de la réplica. Se promedian los cocientes de las 30 semillas. carrier_occupancy_comparisons.csv contiene sus intervalos pareados.', '', '| Política | Carros: útil % | Carros: útil + auxiliar % | Operario abajo % | Operario arriba % |', '|---|---:|---:|---:|---:|']
for policy in 'ABCD':
 group=[r for r in occupancy_rows if r['rate_per_hour']=='24' and r['pattern']=='alternating' and r['policy']==policy]
 service=[r for r in nominal if r['policy']==policy]
 low=statistics.mean(float(r['operator_busy_lower_s'])/float(r['simulation_s']) for r in service)
 high=statistics.mean(float(r['operator_busy_upper_s'])/float(r['simulation_s']) for r in service)
 lines.append(f'| {policy} | {100*mean(group,"useful_carrier_occupancy"):.2f} | {100*mean(group,"total_carrier_occupancy"):.2f} | {100*low:.2f} | {100*high:.2f} |')

lines+=['', '**Verificado dentro de la simulación nominal:** B, C y D reducen trabajo motriz positivo respecto de A; sus tres intervalos energéticos están bajo cero. Los intervalos de cumplimiento por pedidos incluyen cero. **Inferido:** los datos no establecen una mejora o empeoramiento de puntualidad en ese caso, y no bastan para declarar una política superior en general. A 36 pedidos/h, los promedios de cumplimiento de la matriz caen a 78,7–88,1 %; ninguna política garantiza todos los plazos de estas demandas.', '', '## Cierre físico y balance del modelo','',f'**Verificado:** todos entregan la demanda completa, restituyen sus módulos identificados y cierran vacíos en la posición inicial. Máxima diferencia de energía almacenada: {max(abs(float(r["energy_delta_J"])) for r in rows):.6g} J, inferior a 0,1 J; topes registrados: {max(float(r["governor_or_stop_count"]) for r in rows):g}. Máximo residuo absoluto final: {max(abs(float(r["residual_J"])) for r in rows):.6g} J. Máxima suma por réplica de errores absolutos del predictor de trabajo positivo por viaje: {max(float(r["predictor_absolute_error_J"]) for r in rows):.6g} J.', '', 'Los acumuladores mecánicos se integran en cada paso de 0,002 s; la campaña conserva resúmenes terminales, todos los eventos e inventarios y estado compacto cada 5 s. Las series densas se reservan a validaciones y capturas. El trabajo absorbido, las pérdidas, el intercambio de masa y el residuo están separados en run_metrics.csv. La pequeña diferencia del predictor mide consistencia con el mismo núcleo, no precisión física independiente. derived_comparisons.csv añade 420 intervalos pareados por kg útil, pérdidas, intercambio de masa, residuo, error acumulado del predictor, viajes, manipulación, tiempo de restitución y fracción de tiempo ocupado de cada operario (tiempo ocupado/tiempo total). Los cocientes por kg se calculan por semilla antes de restar; no se usa el cociente de medias.', '', '## Sensibilidad eléctrica hipotética','', 'Se entregan 18 combinaciones de eficiencia motriz (70/85/95 %), potencia auxiliar durante todo el tiempo encendido (0/5/20 W) y aprovechamiento mecánico absorbido (0/50 %). electrical_runs.csv separa consumo estimado, recuperación potencial y saldo hipotético. electrical_comparisons.csv contiene diferencias pareadas e intervalos. **Inferido:** esperar o manipular buffers puede borrar ahorros mecánicos al incluir el tiempo de auxiliares. No se presupone batería ni una recuperación eléctrica observada.', '', '## Validación y vídeos','', f'**Verificado:** semilla {selected["seed"]}, archivo {selected["dataset"]}; A está a {abs(selected["baseline_selected_positive_J"]-selected["baseline_median_positive_J"]):.6g} J de la mediana nominal. El ejemplo contiene 19 pedidos y 110 kg útiles; A/C entregan 18 dentro de plazo y B/D los 19 en esta semilla. Cuatro ejecuciones completas de Gazebo coinciden exactamente con CLI en cinco CSV físicos y demand_status.csv. Sus resúmenes de demanda coinciden con la réplica de campaña. Cada captura parcial también tiene paridad de seis CSV hasta su parada real.', '', 'Los cuatro vídeos muestran la misma ventana [600,1200) s, 3000 fotogramas, 1920×1080, 20 fps y 150 s a 4×. Las dos cámaras son sensores de Gazebo; el HUD se compone después con la última muestra anterior o simultánea. Sus auditorías comprueban las marcas de cámara, el desfase de telemetría, decodificación estricta, formato y hashes. La sincronización se verifica por marcas temporales; el período visual nominal de las poses es 0,1 s. La revisión visual de fotogramas se registra en visual_review.json. Los rótulos Cargando/Descargando identifican la etapa del servicio, que puede incluir espera por una ventana del operario; la disponibilidad se muestra aparte. El comienzo y fin efectivos de cada manipulación están en operations.csv. En la frontera exacta de una ventana, la marca redondeada del vídeo puede coincidir con una muestra todavía anterior a su apertura; no se ejecuta una operación fuera de horario.','', '| Política | Vídeo | Vista previa |','|---|---|---|']
for p,name in zip('ABCD',('A_inmediato.mp4','B_coordinado.mp4','C_inmediato_buffers.mp4','D_coordinado_buffers.mp4')):
 lines.append(f'| {p} | [{name}](evidence/demand_pilot_20261026/{name}) | [Fotograma](evidence/demand_pilot_20261026/{p}_preview.png) |')
electrical=list(csv.DictReader((analysis/'electrical_comparisons.csv').open()))
lines+=['', '## Referencia eléctrica nominal: η=85 %, auxiliares=5 W, recuperación=0 %', '', '**Inferido bajo esos supuestos:** el tiempo adicional puede invertir el ahorro mecánico. En esta referencia C y D tienen mayor saldo estimado que A; B no establece diferencia porque su intervalo incluye cero.', '', '| Diferencia | Saldo hipotético J: media [IC 95 %] |', '|---|---:|']
for contrast in ('B-A','C-A','D-A'):
 r=next(r for r in electrical if r['rate_per_hour']=='24' and r['pattern']=='alternating' and r['contrast']==contrast and r['metric']=='E_net_J' and r['eta_motor']=='0.85' and r['P0_W']=='5' and r['eta_regen']=='0')
 lines.append(f'| {contrast} | {float(r["mean"]):+.2f} [{float(r["ci95_low"]):+.2f}, {float(r["ci95_high"]):+.2f}] |')

lines+=['','**Pendiente fuera del hito:** contacto rueda–cable, cierre energético físico completo del cable y los péndulos, resistencia, fatiga y capacidad de bases/suelo. Estas comprobaciones no son certificación estructural ni de seguridad. Las validaciones de comandos y cierre del ROS histórico ya están documentadas en [validacion_minima_20261026.md](validacion_minima_20261026.md); no se repitieron recorridos históricos.','','## Procedencia y fallos conservados','','La revisión parte de 6a824b4 en feat/ballasted-two-carrier-demo, con cambios locales identificados por hashes. El campo seed=0 de los metadatos geométricos corresponde a la escena física determinista; la demanda del ejemplo es la semilla 26 del manifiesto y su CSV queda identificado por SHA-256. No se sortea demanda durante la integración. El rótulo común scripted_inputs de summary.json es histórico; la política efectiva y su servicio se registran en demand_summary.json y demand_status.csv. Los registros de identidad de módulos se inicializan en todas las políticas para auditar conservación; A/B no habilitan su uso y el HUD muestra Buffers deshabilitados. La campaña preliminar 01 (42 completadas, una interrupción y 677 pendientes) queda excluida tras corregir la protección de plazos de todo el trabajo conocido. La campaña 02 conserva exactamente las mismas 180 entradas. Las guardas conservan admisión, pico RSS, mínimo libre, códigos de salida y limpieza. En la primera tanda nativa, A/B aprobaron y la admisión de C quedó bajo 7 GiB antes de crear un simulador; se conserva native_C/validation.json y se reanudó C/D en directorios nuevos. También se conserva un bloqueo de admisión de vídeo bajo 8 GiB antes de iniciar Gazebo; el perfil se calibró a 7,5 GiB según el pico previo de 2,2213 GiB, manteniendo parada bajo 5 GiB y reserva de 4 GiB. Se conserva además un primer fallo de lanzador de codificación por separadores Windows/WSL; se corrigió la ruta antes de codificar, sin repetir la captura. La verificación parcial de D se detuvo antes de ejecutar CLI porque conservaba el umbral nativo de 7 GiB; se corrigió exclusivamente ese perfil a 6 GiB y se completó la referencia con la misma captura. Los intentos fallidos de admisión previos siguen en results. Las versiones, fuentes y binarios están archivados junto con los eventos y procedencia.','','[Datos, intervalos y manifiesto](evidence/demand_pilot_20261026/manifest.json) · [Auditoría completa](evidence/demand_pilot_20261026/audit_full_01.json) · [Análisis](evidence/demand_pilot_20261026/analysis.json)']
(root/'docs/resultados_demanda.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
# Include a portable report inside the evidence bundle as well.
(evidence/'informe.md').write_text(('\n'.join(lines)+'\n').replace('evidence/demand_pilot_20261026/','').replace('](piloto_demanda.md)','](../../piloto_demanda.md)').replace('](validacion_minima_20261026.md)','](../../validacion_minima_20261026.md)'),encoding='utf-8')
with zipfile.ZipFile(evidence/'delivery_sources.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for directory in ('include','src','scripts','tests','config'):
  for path in (root/directory).rglob('*'):
   if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc': archive.write(path,path.relative_to(root))
 for path in base.glob('*.py'): archive.write(path,path.relative_to(root))
 for path in (root/'CMakeLists.txt',root/'install/agro_teleferico/lib/agro_teleferico/agro_loop_cli',root/'install/agro_teleferico/lib/libAgroLoopSystem.so'):
  archive.write(path,path.relative_to(root))
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in evidence.iterdir() if p.is_file()}
(evidence/'manifest.json').write_text(json.dumps({'schema':'agro-demand-delivery-v1','classification':'verified computational evidence; physical limits documented','artifacts_sha256':manifest,'binary_sha256':json.loads((campaign/'execution.json').read_text())['binary_sha256']},indent=2),encoding='utf-8')
pilot=root/'docs/piloto_demanda.md'; body=pilot.read_text(encoding='utf-8')
old='**Pendiente/en curso:** terminar y auditar las 720 ejecuciones de la revisión\n2, calcular los intervalos pareados, validar la semilla seleccionada en Gazebo\ny producir sus cuatro vídeos. Los resultados de estrés no sustituyen la\ncomparación de la campaña completa.'
new='**Verificado:** las 720 ejecuciones se completaron y aprobaron la auditoría independiente. Se entregan comparación pareada, sensibilidad eléctrica, cuatro validaciones completas en Gazebo y cuatro vídeos con HUD. Los resultados y límites están en [resultados_demanda.md](resultados_demanda.md).'
assert old in body; pilot.write_text(body.replace(old,new),encoding='utf-8')
readme=root/'README.md'; text=readme.read_text(encoding='utf-8'); text+='\nEl [informe comparativo de demanda](docs/resultados_demanda.md) incluye las 720 ejecuciones auditadas, los intervalos pareados y los cuatro vídeos con HUD.\n'; readme.write_text(text,encoding='utf-8')
print('Evidence exported:',len(manifest),'files')
