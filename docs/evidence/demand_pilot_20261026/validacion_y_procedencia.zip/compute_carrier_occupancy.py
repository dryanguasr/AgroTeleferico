from pathlib import Path
import csv,json,sys,hashlib,itertools,math
base=Path(__file__).resolve().parent; root=base.parents[1]; sys.path.insert(0,str(root/'scripts'))
from analyze_demand import CONTRASTS,bootstrap_columns,describe
campaign=root/'results/demand_campaign_02'; folder=root/'results/demand_analysis_02'
def occupancy(trips,orders):
 distance=useful_distance=total_distance=0.
 for trip in trips:
  if trip['event']!='begin': continue
  stamp=float(trip['time_s']); leg=float(trip['distance_m']); total=float(trip['up_kg'])+float(trip['down_kg'])
  useful=sum(float(order['mass_kg']) for order in orders if float(order['loaded_s'])<=stamp+1e-6 and float(order['delivered_s'])>stamp+1e-6)
  assert leg>0 and -1e-7<=useful<=total+1e-6 and total<=20+1e-6
  distance+=leg; useful_distance+=leg*useful; total_distance+=leg*total
 return {'useful_carrier_occupancy':useful_distance/(20*distance) if distance else 0.,'total_carrier_occupancy':total_distance/(20*distance) if distance else 0.,'aux_carrier_occupancy':(total_distance-useful_distance)/(20*distance) if distance else 0.,'nominal_line_distance_m':distance}
fixture=[{'event':'begin','time_s':1,'distance_m':10,'up_kg':5,'down_kg':5},{'event':'begin','time_s':3,'distance_m':10,'up_kg':0,'down_kg':0}]
assert occupancy(fixture,[{'mass_kg':10,'loaded_s':0,'delivered_s':2}])['useful_carrier_occupancy']==.25
manifest=json.loads((campaign/'dataset.json').read_text()); datasets={r['id']:r for r in manifest['datasets']}; rows=[]; inputs={}
for r in json.loads((campaign/'campaign.json').read_text())['runs']:
 assert r['state']=='completed'
 source=campaign/r['attempt']/'output'
 trip_file=source/'trips.csv'; order_file=source/'orders.csv'
 inputs[r['dataset']+'/'+r['policy']]={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in [('trips.csv',trip_file),('orders.csv',order_file)]}
 with trip_file.open() as f: trips=list(csv.DictReader(f))
 with order_file.open() as f: orders=list(csv.DictReader(f))
 data=datasets[r['dataset']]
 rows.append({'dataset':r['dataset'],'policy':r['policy'],'rate_per_hour':data['rate_per_hour'],'pattern':data['pattern'],'seed':data['seed'],**occupancy(trips,orders)})
def write(name,data):
 path=folder/name; assert not path.exists()
 with path.open('w',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=list(data[0])); writer.writeheader(); writer.writerows(data)
write('carrier_occupancy.csv',rows)
result=[]
for rate,pattern in itertools.product((12,24,36),('balanced','alternating')):
 paired={seed:{r['policy']:r for r in rows if r['rate_per_hour']==rate and r['pattern']==pattern and r['seed']==seed} for seed in range(30)}
 for contrast,coefficients in CONTRASTS.items():
  assert all(set(p)==set('ABCD') for p in paired.values())
  columns={m:[sum(c*paired[seed][p][m] for p,c in coefficients.items()) for seed in range(30)] for m in ('useful_carrier_occupancy','total_carrier_occupancy','aux_carrier_occupancy')}
  draws=bootstrap_columns(columns,['agro-demand-bootstrap-v1',rate,pattern,contrast],10000)
  for metric in columns: result.append({'rate_per_hour':rate,'pattern':pattern,'contrast':contrast,'metric':metric,'planned_pairs':30,'excluded_pairs':0,**describe(columns[metric],draws[metric],.95)})
write('carrier_occupancy_comparisons.csv',result)
(folder/'carrier_occupancy_analysis.json').write_text(json.dumps({'classification':'verified computational reconstruction','definition':'mass times nominal trip arc divided by 2 carriers * 10 kg * total nominal trip arc; includes empty trips and restoration','useful_mass':'whole loaded orders not yet delivered at the departure instant; handling at rest is excluded from distance','analytical_check':'10 kg across two carriers over 10 m, then empty over 10 m -> useful occupancy 25 percent','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':inputs,'bootstrap_replicates':10000,'excluded_pairs':0},indent=2))
print('Occupancy reconstructed for',len(rows),'runs')
