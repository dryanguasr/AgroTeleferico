from pathlib import Path
import json,time
root=Path.cwd().resolve(); target=str(root/'results/demand_delivery_02'); live=[]
for entry in Path('/proc').iterdir():
 if not entry.name.isdigit(): continue
 try: args=(entry/'cmdline').read_bytes().decode(errors='replace').split(chr(0))
 except (FileNotFoundError,ProcessLookupError,PermissionError): continue
 if any(target in arg and (arg.endswith('.sdf') or arg.endswith('.mp4')) for arg in args): live.append({'pid':int(entry.name),'argv':args})
result={'unix_s':time.time(),'live_delivery_simulators_or_encoders':live,'passed':not live}
(root/'results/demand_delivery_02/final_process_check.json').write_text(json.dumps(result,indent=2)); print(json.dumps(result))
assert not live
