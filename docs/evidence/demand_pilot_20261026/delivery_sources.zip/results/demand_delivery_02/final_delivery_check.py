from pathlib import Path
import json,hashlib,zipfile,re,subprocess,time
root=Path.cwd(); base=root/'results/demand_delivery_02'; evidence=root/'docs/evidence/demand_pilot_20261026'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((evidence/'manifest.json').read_text())
assert all(digest(evidence/name)==value for name,value in manifest['artifacts_sha256'].items())
assert json.loads((base/'final_process_check.json').read_text())['passed']
# Successful final outputs retain the same source physics and video bytes.
frozen=json.loads((root/'results/demand_campaign_02/execution.json').read_text())
assert all(digest(root/p)==value for p,value in frozen['source_sha256'].items())
assert digest(root/'install/agro_teleferico/lib/agro_teleferico/agro_loop_cli')==frozen['binary_sha256']
for p in 'ABCD':
 audit=json.loads((base/f'hud_{p}/audit.json').read_text()); name=audit['output_file']
 assert audit['passed'] and audit['strict_decode'] and digest(evidence/name)==audit['output_sha256']
 assert audit['output_video']['nb_read_frames']=='3000' and audit['output_video']['duration']=='150.000000'
for archive in evidence.glob('*.zip'):
 with zipfile.ZipFile(archive) as z: assert z.testzip() is None,archive
resources={}
for folder in ('demand_campaign_guard_02','demand_native_guard_02','demand_native_guard_03','demand_media_guard_02','demand_media_guard_03','demand_capture_verify_d_guard_02','demand_compose_a_guard_01','demand_compose_a_guard_02','demand_compose_b_guard_01','demand_compose_c_guard_01','demand_compose_d_guard_01'):
 path=root/'results'/folder/'guard_summary.json'
 if path.exists():
  row=json.loads(path.read_text()); assert not row['remaining_owned_pids']; resources[folder]=row
capture=resources['demand_media_guard_03']
assert capture['min_host_free_gib']>=5 and not capture['escalations']
resource_data={'classification':'verified measurements; tree RSS and host free memory are different quantities','profiles_gib':{'CLI_admission':6,'native_admission':7,'headless_demand_video_admission':7.5,'preventive_stop_below':5,'reserve':4},'capture_peak_tree_rss_gib':capture['peak_tree_rss_gib'],'capture_min_host_free_gib':capture['min_host_free_gib'],'guard_results':resources}
(evidence/'resource_summary.json').write_text(json.dumps(resource_data,indent=2),encoding='utf-8')
(evidence/'final_process_check.json').write_bytes((base/'final_process_check.json').read_bytes())
paragraph=f'**Verificado en las cuatro capturas completas:** pico RSS del árbol de {capture["peak_tree_rss_gib"]:.4f} GiB y mínimo libre Windows de {capture["min_host_free_gib"]:.4f} GiB. No se activó la parada preventiva; los cuatro procesos Gazebo terminaron con código 0. Se mantienen los perfiles finales CLI=6, nativo=7 y vídeo sin GUI=7,5 GiB, con parada bajo 5 GiB y reserva de 4 GiB. Véase [resource_summary.json](evidence/demand_pilot_20261026/resource_summary.json).'
report=root/'docs/resultados_demanda.md'; body=report.read_text(encoding='utf-8'); body+='\n## Recursos y cierre\n\n'+paragraph+'\n'; report.write_text(body,encoding='utf-8')
(evidence/'informe.md').write_text(body.replace('evidence/demand_pilot_20261026/','').replace('](piloto_demanda.md)','](../../piloto_demanda.md)').replace('](validacion_minima_20261026.md)','](../../validacion_minima_20261026.md)'),encoding='utf-8')
pilot=root/'docs/piloto_demanda.md'; body=pilot.read_text(encoding='utf-8'); old='**Pendiente:** verificar el pico durante los vídeos completos; la prueba corta no garantiza el máximo de una ejecución larga.'; assert old in body; body=body.replace(old,f'**Verificado en vídeos completos:** pico del árbol {capture["peak_tree_rss_gib"]:.4f} GiB; mínimo libre Windows {capture["min_host_free_gib"]:.4f} GiB, sin activar la parada preventiva.'); pilot.write_text(body,encoding='utf-8')
# Preserve the final verification scripts with their original repository layout.
with zipfile.ZipFile(evidence/'delivery_sources.zip','a',zipfile.ZIP_DEFLATED) as z:
 for filename in ('final_process_check.py','final_delivery_check.py'):
  path=base/filename; z.write(path,path.relative_to(root))
manifest['artifacts_sha256']={p.name:digest(p) for p in evidence.iterdir() if p.is_file() and p.name!='manifest.json'}
manifest['report_sha256']=digest(report)
manifest['final_verification_unix_s']=time.time()
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
for path in (report,evidence/'informe.md'):
 for reference in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
  if '://' not in reference and not reference.startswith('#'): assert (path.parent/reference).exists(),(path,reference)
assert all(digest(evidence/name)==value for name,value in manifest['artifacts_sha256'].items())
result={'passed':True,'artifact_count':len(manifest['artifacts_sha256']),'four_videos_verified':True,'all_report_links_exist':True,'no_delivery_simulators_or_encoders':True,'physics_source_unchanged':True,'git_head_current':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'report':str(report.resolve()),'manifest':str((evidence/'manifest.json').resolve())}
(base/'final_delivery_check.json').write_text(json.dumps(result,indent=2)); print(json.dumps(result))
